------------------------------------------------------------------
 
 DOS Games Loader by GamesNostalgia - www.gamesnostalgia.com
 
 Windows version 1.1
 
------------------------------------------------------------------
 
 RELEASE NOTES:
 
 * This package includes DOSBox 0.74-3
 * Default SDL output is now "overlay"
 * You can launch the game with the shortcut (.lnk) or with the
   .bat file (as requested by linux users)

-----------------------------------------------------------------

 USEFUL KEYS:

 ALT-ENTER     Switch to full screen and back.
 ALT-PAUSE     Pause emulation (hit ALT-PAUSE again to continue).
 CTRL-ALT-F5   Start/Stop creating a movie of the screen.
 CTRL-F5       Save a screenshot. (PNG format)
 CTRL-F10      Capture/Release the mouse.
 CTRL-F11      Slow down emulation (Decrease DOSBox Cycles).
 CTRL-F12      Speed up emulation (Increase DOSBox Cycles)*.
 CTRL-F9       Kill DOSBox.

------------------------------------------------------------------


 SUPPORT GAMESNOSTALGIA! 
 
 If you like what we do, support us on Patreon:
 
        https://www.patreon.com/gamesnostalgia
        
 or with a donation:

        https://gamesnostalgia.com/donate

-----------------------------------------------------------------


 Please go to https://gamesnostalgia.com for more retrogames

 Thanks to DOSBox https://www.dosbox.com/ for the emulator


 --------------------
 GamesNostalgia DOS Windows package version 1.1 - October 2019